import 'package:flutter/material.dart';

class Body extends StatelessWidget {
  const Body({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'About the School',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Image.network(
              "https://rpssansthan.org/admin/org/603engschoolhead.png",
              color: Colors.black,
            ),
            const SizedBox(height: 10),
            const Text(
              "The curriculum is comprehensive and based on core subjects going beyond academic book knowledge but also facilitating development of concepts, ideas and skills. Rajasthan International  School provides best sports facilities and plethora of co-curricular activities that have not been offered in School's before. It offers state-of-the-art boarding facilities with a fully equipped sick bay.",
              style: TextStyle(
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              "The purpose of  Rajasthan International School is to prepare students with promise for higher education and lifelong learning and to enhance their intellectual, physical, social, emotional, spiritual, and artistic growth so that they may realize their power for good as citizens of local and world communities. We recognize that such growth is best nourished in an environment that honours and respects not only a diversity of ideas, perspectives, experiences, and traditions, but also a diversity of peoples within our community. ",
              style: TextStyle(
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              "We acknowledge that a learning environment that welcomes and encourages diversity provides an invaluable opportunity for all, students and adults alike, to develop the skills and appreciation necessary to become vital, contributing members of our increasingly diverse local and global communities. Exposure to a variety of ideas and perspectives enriches student learning as it encourages critical thinking, open mindedness, flexibility, creativity, and problem solving. Because the formative years that a student spends at  Rajasthan International  School is the most impressionable, we believe there is no better time to teach a child to value a diversity of cultures, to honour a variety of traditions, and to respect the contributions of all people.",
              style: TextStyle(
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 10),
            Image.network("https://rpssansthan.org/admin/fileupload/629DSC_3601.jpg"),
            const Text(
              'Vision',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'The strategic method of teaching and training imparted to students, virtually develop their potentionalities and intellect sagacity in a constructive manner of planned schedule, is our VISION to achieve successful career competitively in all respect.',
              style: TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 20),
            const Text(
              'Mission',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'The intellectual character and moral value of students are always kept high in this academy. Our Mission helps the students to meet the challenged ambience with constant endurance and perseverance to lay an incredible land mark on our concrete planning of fidelity. We would proceed forward with strong determination for achieving the goal of success and shall leave no stone behind at any turning of crucial confronts.',
              style: TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 10),
          ],
        ));
  }
}
