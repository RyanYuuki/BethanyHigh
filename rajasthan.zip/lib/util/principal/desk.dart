import 'package:flutter/material.dart';

class Desk extends StatelessWidget {
  const Desk({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Column(
        children: [
          const Text(
            'Principal',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          Image.network(
            "https://rpssansthan.org/admin/fileupload/676school-principal.jpg",
            height: 300,
            width: 300,
            fit: BoxFit.cover,
          ),
          const SizedBox(
            height: 10,
          ),
          const Text(
            'Smt. Mukesh Sahu',
            style: TextStyle(fontSize: 24),
          ),
          const Text(
            'M.A. B.Ed\n(Principal)',
            style: TextStyle(fontSize: 18),
          ),
          const SizedBox(height: 20),
          const Text(
            'Its my great pleasure to let you know about the vision and commitment that I have foreseen as a Principal for the better cognition of your child at Rajasthan International  School. In recent years, most parents want their children study in English medium school which is the demand of time, too. Therefore, to fulfill the desire of the parents and the requirements of the country to produce the qualified, skilled and competitive workforce, several English medium schools have been established to teach and train the children from the very beginning with different programs and being affiliated to different national and international Boards of Education.',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 10),
          const Text(
            "Rajasthan International School has been established aiming to provide the best education around the Shekhawati region with the ample infrastructures and all the facilities that are required for the over all development of an individual child. In the tranquil and serene natural environment, students will learn through the best and modern educational teaching practices. The whole educational environment will completely be English where neither the teachers nor students talk in Hindi besides during Hindi lesson whether in the classroom or outside. Highly educated and trained teachers form different well known cities of the country will create the best learning milieus for the advancement of each student's creativity so that they can inquisitively innovate the new ideas and methods.",
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 10),
          const Text(
            "As a principal, I'll do my best to implement the best and well known international teaching practices. Teachers will be trained time and again to accustom with the new and updated teaching practices. English that our Students speak will completely be different from local and pronunciation will be correct as native speakers of English use. We won't enforce the students to be doctor or engineer or any other particular profession in the future but encourage them, motivate and vitalize them with new zeal and vigor to unveil their potentiality and hidden talent. We let them strive to expose their ingenuity. I want each of my students should have holistic development so that they will be efficient to overcome the hindrances on the way to success",
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 10),
          const Text(
            "I make a humble request to all the parents, guardians, brothers, sisters, teachers, students and all the well wishers to cooperate me and my team to mould the tender minds into perfect shapes then grow and develop the better future of our children who will be strong pillars of the nation with their utmost devotion and skills",
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}
