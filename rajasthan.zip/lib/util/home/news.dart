import 'package:flutter/material.dart';

class News extends StatefulWidget {
  const News({super.key});

  @override
  State<News> createState() => _NewsState();
}

List<String> news = [
  "Rajasthan International School is a premier day boarding school offering a world class in close proximity to Dausa , with super connectivity to Jaipur via State Highway. The school offers an national platform with a perfect blend of technology, modern pedagogy, culture and innovation. facilities. Rajasthan International School follows both the national and the International curriculum.",
  "The curriculum is comprehensive and based on core subjects going beyond academic book knowledge but also facilitating development of concepts, ideas and skills. Rajasthan International School provides best sports facilities and plethora of co-curricular activities that have not been offered in School's before. It offers state-of-the-art boarding facilities with a fully equipped sick bay.",
  "The curriculum is comprehensive and based on core subjects going beyond academic book knowledge but also facilitating development of concepts, ideas and skills. Rajasthan International School provides best sports facilities and plethora of co-curricular activities that have not been offered in School's before. It offers state-of-the-art boarding facilities with a fully equipped sick bay.",
  "We acknowledge that a learning environment that welcomes and encourages diversity provides an invaluable opportunity for all, students and adults alike, to develop the skills and appreciation necessary to become vital, contributing members of our increasingly diverse local and global communities. Exposure to a variety of ideas and perspectives enriches student learning as it encourages critical thinking, open mindedness, flexibility, creativity, and problem solving. Because the formative years that a student spends at Rajasthan International School is the most impressionable, we believe there is no better time to teach a child to value a diversity of cultures, to honour a variety of traditions, and to respect the contributions of all people.",
  "Therefore, Rajasthan International School is committed to the development and maintenance of an inclusive community in which racial, religious, economic, and other diverse groups are welcomed."
];

class _NewsState extends State<News> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(
            height: 10,
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 15.0),
            child: Text(
              "Introduction",
              style: TextStyle(fontSize: 20),
              textAlign: TextAlign.start,
            ),
          ),
          ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            addAutomaticKeepAlives: false,
            shrinkWrap: true,
            itemCount: news.length,
            itemBuilder: (context, index) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ListTile(
                    title: Text(
                      news[index],
                      textAlign: TextAlign.justify,
                    ),
                    tileColor: Colors.grey[200],
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}
