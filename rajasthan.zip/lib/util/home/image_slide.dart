import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class ImageSlide extends StatelessWidget {
  ImageSlide({super.key});

  final List<String> image = [
    "https://rpssansthan.org/admin/banner/775banner3.jpg",
    "https://rpssansthan.org/admin/banner/723Banner8.jpg",
    "https://rpssansthan.org/admin/banner/254Banner9.jpg",
    "https://rpssansthan.org/admin/banner/191Banner10.jpg",
    "https://rpssansthan.org/admin/banner/644Untitled-1.jpg",
    "https://rpssansthan.org/admin/banner/926Banner7.jpg",
    "https://rpssansthan.org/admin/banner/957Banner13.jpg",
  ];

  @override
  Widget build(BuildContext context) {
    return CarouselSlider(
      options: CarouselOptions(autoPlay: true),
      items: image
          .map(
            (item) => Container(
              child: Center(
                child: Image.network(
                  item.toString(),
                  fit: BoxFit.cover,
                  width: 1000,
                  height: 400,
                ),
              ),
            ),
          )
          .toList(),
    );
  }
}
