import 'package:flutter/material.dart';

class CustomAppbar extends StatelessWidget implements PreferredSizeWidget {
  const CustomAppbar({super.key});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Row(
        children: [
          Image.network(
            "https://rpssansthan.org/admin/org/5094.png",
            height: 50,
            width: 50,
            fit: BoxFit.cover,
          ),
          const SizedBox(width: 10),
          const Text("Rajasthan Internation School",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17))
        ],
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(60);
}
