package com.example.schoolapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
