import 'package:schoolapp/util/Contact/body.dart';
import 'package:flutter/material.dart';

import '../component/appbar.dart';
import '../component/drawer.dart';

class Contact extends StatefulWidget {
  const Contact({super.key});

  @override
  State<Contact> createState() => _ContactState();
}

class _ContactState extends State<Contact> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppbar(),
      drawer: const Drawers(),
      body: ListView(
        children: const [ContactBody()],
      ),
    );
  }
}
