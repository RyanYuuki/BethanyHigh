import 'package:schoolapp/util/about/body.dart';
import 'package:flutter/material.dart';

import '../component/appbar.dart';
import '../component/drawer.dart';

class About extends StatefulWidget {
  const About({super.key});

  @override
  State<About> createState() => _AboutState();
}

class _AboutState extends State<About> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppbar(),
      drawer: const Drawers(),
      body: ListView(
        children: const [Body()],
      ),
    );
  }
}
