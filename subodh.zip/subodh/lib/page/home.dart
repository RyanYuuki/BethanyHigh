import 'package:schoolapp/component/drawer.dart';
import 'package:schoolapp/util/home/gallery.dart';
import 'package:schoolapp/util/home/news.dart';
import 'package:flutter/material.dart';

import '../component/appbar.dart';
import '../util/home/image_slide.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppbar(),
      drawer: const Drawers(),
      body: ListView(
        children: [
          ImageSlide(),
          const SizedBox(height: 15),
          const News(),
          const SizedBox(height: 15),
          const Gallery(),
        ],
      ),
    );
  }
}
