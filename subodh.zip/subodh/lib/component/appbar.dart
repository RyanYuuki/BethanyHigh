import 'package:flutter/material.dart';

class CustomAppbar extends StatelessWidget implements PreferredSizeWidget {
  const CustomAppbar({super.key});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Row(
        children: [
          Image.asset(
            "assets/image/logo.png",
            height: 50,
            width: 40,
            fit: BoxFit.cover,
          ),
          const SizedBox(width: 10),
          const Text("Subodh Public School",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17))
        ],
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(60);
}
