import 'package:flutter/material.dart';

class ContactBody extends StatelessWidget {
  const ContactBody({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Contact Us",
            style: TextStyle(fontSize: 26),
          ),
          const SizedBox(
            height: 20,
          ),
          const Text(
            'Subodh English Medium School',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'Rambagh Crossing, Bhawani Singh Marg, Jaipur-302015',
            style: TextStyle(color: Color.fromARGB(255, 37, 37, 37)),
          ),
          const SizedBox(height: 8),
          const Text(
            'Phone: +91-141-2568477, 2572426',
            style: TextStyle(color: Color.fromARGB(255, 37, 37, 37)),
          ),
          const SizedBox(height: 8),
          const Text(
            'Email: info@spsjaipur.com',
            style: TextStyle(color: Color.fromARGB(255, 37, 37, 37)),
          ),
          const SizedBox(height: 24),
          const Text(
            'Send Us a Message',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          const Text(
            'Your Name',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const TextField(
            decoration: InputDecoration(
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Your Email',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const TextField(
            decoration: InputDecoration(
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Your Message',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const TextField(
            decoration: InputDecoration(
              border: OutlineInputBorder(),
            ),
            maxLines: 5,
          ),
          const SizedBox(height: 16),
          InkWell(
            onTap: () {},
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: 60,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                color: Colors.deepPurple,
              ),
              child: Center(
                child: Text(
                  "Send a Message",
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
