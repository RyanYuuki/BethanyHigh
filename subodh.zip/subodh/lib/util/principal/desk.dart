import 'package:flutter/material.dart';

class Desk extends StatelessWidget {
  const Desk({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Principal',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          Image.asset(
            "assets/image/principle.jpg",
            height: 300,
            width: 300,
            fit: BoxFit.cover,
          ),
          const SizedBox(
            height: 10,
          ),
          const Text(
            'Mrs. Raani Yadav',
            style: TextStyle(fontSize: 24),
          ),
          const SizedBox(height: 20),
          const Text(
            'How we perceive a student is how we perceive tomorrow. A student is a seed of change and evolution. Subodh Public School nurture this process. Each student is empowered to optimize his/her talent and potential to the fullest.',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 10),
          const Text(
            "At Subodh Public School, the students' emotional, physical and intellectual facets are shaped with the energies of perseverance, thoughtfulness, dedication and support. A professional, empowered and motivated faculty ensures the overall growth of the student. This equips the students with an innovative and educational way of learning and in the process become the torch bearers of tomorrow. ",
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 10),
          const Text(
            "God bless and all the best! ",
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 10),
          const Text(
            "Mrs. Kamaljeet Yadav\nPrincipal ",
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}
