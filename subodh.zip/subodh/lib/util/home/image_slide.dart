import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class ImageSlide extends StatelessWidget {
  ImageSlide({super.key});

  final List<String> image = [
    "https://www.subodhpublicschool.com/img/Banner1.jpg",
    "https://www.subodhpublicschool.com/img/Banner2.jpg",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSolkWHMJQjBA-KYBdN0wAkP2HM1kJ-_nXl3A&s",
    "https://skoodos.com/public/uploads/optimized/1681272973.png",
  ];

  @override
  Widget build(BuildContext context) {
    return CarouselSlider(
      options: CarouselOptions(autoPlay: true),
      items: image
          .map(
            (item) => Container(
              child: Center(
                child: Image.network(
                  item.toString(),
                  fit: BoxFit.cover,
                  width: 1000,
                  height: 400,
                ),
              ),
            ),
          )
          .toList(),
    );
  }
}
