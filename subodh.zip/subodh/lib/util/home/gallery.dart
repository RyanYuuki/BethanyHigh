import 'package:flutter/material.dart';

class Gallery extends StatefulWidget {
  const Gallery({super.key});

  @override
  State<Gallery> createState() => _GalleryState();
}

List<String> gallery = [
  "assets/image/imag2.jpg",
  "assets/image/image1.jpg",
  "assets/image/image3.jpg",
  "assets/image/image4.jpg",
  "https://rpssansthan.org/admin/gallery/144gallery6.jpg",
  "https://rpssansthan.org/admin/gallery/51gallery8.jpg",
  "https://rpssansthan.org/admin/gallery/566Gal9.jpg",
  "https://rpssansthan.org/admin/gallery/410Gal6.jpg",
];

class _GalleryState extends State<Gallery> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: const EdgeInsets.only(top: 30, left: 15, right: 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Gallery",
            style: TextStyle(
              fontSize: 24,
            ),
            textAlign: TextAlign.start,
          ),
          const SizedBox(
            height: 10,
          ),
          GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              addAutomaticKeepAlives: false,
              shrinkWrap: true,
              itemCount: gallery.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 15, mainAxisSpacing: 15),
              itemBuilder: (context, index) {
                return GridTile(
                  child: gallery[index].contains('assets')
                      ? Image.asset(gallery[index])
                      : Image.network(
                          gallery[index],
                        ),
                );
              }),
        ],
      ),
    );
  }
}
